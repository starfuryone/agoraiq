# AgoraIQ Market Intelligence — Deployment Guide

## What's in this package

| File | Purpose |
|---|---|
| `setup.sh` | Full automated install (run once on server) |
| `public/index.html` | The `intel.agoraiq.net` frontend (drop into `/opt/agoraiq-market-intelligence/public/`) |
| `caddy-intel.conf` | Caddy config snippet to append to `/etc/caddy/Caddyfile` |
| `dashboard-integration.html` | How to wire the nav link into `app.agoraiq.net` |

---

## Quick Install (automated)

```bash
# 1. Upload the agoraiq-market-intelligence-v6.zip to server
scp agoraiq-market-intelligence-v6.zip root@your-server:/tmp/

# 2. On server: extract and run setup
cd /tmp
unzip agoraiq-market-intelligence-v6.zip -d agoraiq-mi
cp /path/to/this-deploy-package/* agoraiq-mi/
chmod +x agoraiq-mi/setup.sh
bash agoraiq-mi/setup.sh
```

The script will:
- Install to `/opt/agoraiq-market-intelligence`
- Run `prisma migrate deploy` (creates `market_intelligence` schema in your existing DB)
- Create `/etc/systemd/system/agoraiq-market-intelligence.service`
- Append `intel.agoraiq.net` block to `/etc/caddy/Caddyfile` and reload
- Install a cron job for sync every 6 hours
- Copy SOCKS5 proxy settings from your main `/opt/agoraiq/.env`
- Run an initial full sync in the background

---

## Manual Steps (if you prefer)

### 1. Install the service

```bash
mkdir /opt/agoraiq-market-intelligence
cp -r /tmp/agoraiq-market-intelligence-v6/. /opt/agoraiq-market-intelligence/
cd /opt/agoraiq-market-intelligence
npm install --production
```

### 2. Configure `.env`

```env
NODE_ENV=production
PORT=3001
DATABASE_URL=postgresql://agoraiq:YOUR_PASSWORD@127.0.0.1:5432/agoraiq?schema=market_intelligence
REDIS_URL=redis://127.0.0.1:6379
CORS_ORIGIN=https://intel.agoraiq.net,https://app.agoraiq.net
LOG_LEVEL=info
# SOCKS5_HOST=  (from your main .env if needed)
# SOCKS5_PORT=1080
```

### 3. Migrate database

```bash
DATABASE_URL="..." npx prisma migrate deploy --schema=prisma/schema-markets.prisma
```

This creates a `market_intelligence` schema in your **existing** `agoraiq` database — no new Postgres instance needed.

### 4. Deploy the frontend

```bash
mkdir -p /opt/agoraiq-market-intelligence/public
cp public/index.html /opt/agoraiq-market-intelligence/public/
```

### 5. Update Caddy

```bash
cat caddy-intel.conf >> /etc/caddy/Caddyfile
caddy validate --config /etc/caddy/Caddyfile
caddy reload --config /etc/caddy/Caddyfile
```

### 6. Systemd service

```bash
cat > /etc/systemd/system/agoraiq-market-intelligence.service << 'EOF'
[Unit]
Description=AgoraIQ Market Intelligence Layer v6
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/agoraiq-market-intelligence
EnvironmentFile=/opt/agoraiq-market-intelligence/.env
ExecStart=/usr/bin/node src/server.mjs
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=agoraiq-market-intelligence

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable agoraiq-market-intelligence
systemctl start agoraiq-market-intelligence
```

---

## Dashboard Integration (app.agoraiq.net)

Open `dashboard-integration.html` for the full code. Short version:

Find your sidebar nav (wherever "Dashboard", "Signals" etc. are defined) and add a new item:

**If your nav is HTML:**
```html
<a href="https://intel.agoraiq.net" target="_blank"
   style="display:flex;align-items:center;gap:10px;padding:9px 10px;
          border-radius:6px;color:#94a3b8;text-decoration:none;font-size:12px;">
  <span>⟡</span>
  <span>Market Intel</span>
  <span style="font-size:8px;color:#64748b">↗</span>
</a>
```

**If your nav is TypeScript/React**, add to your NAV array:
```typescript
{ key: "market-intel", label: "Market Intel", icon: "⟡", href: "https://intel.agoraiq.net" }
```

---

## Architecture

```
intel.agoraiq.net          app.agoraiq.net
      │                          │
      ▼                          ▼
  Caddy :443               Caddy :443
      │                          │
  /api/*  → port 3001           /api/* → port 4000
  /       → /opt/.../public/    /      → packages/web/public
      │
      ▼
  agoraiq-market-intelligence  (systemd)
  node src/server.mjs :3001
      │                    │
      ▼                    ▼
  PostgreSQL           Redis :6379
  schema: market_intelligence   (existing instance)
  (same DB as AgoraIQ)
```

---

## Verify Everything Works

```bash
# Service running?
systemctl status agoraiq-market-intelligence

# Health check
curl https://intel.agoraiq.net/health

# API responding?
curl https://intel.agoraiq.net/api/v1/markets/summary

# Logs
journalctl -u agoraiq-market-intelligence -f

# Sync logs
tail -f /var/log/agoraiq-mi-sync.log
```

## Switch from Mock to Live Data

Once the service is running and `intel.agoraiq.net/health` returns `{"database":"ok"}`, edit `public/index.html` and change:

```javascript
// Near the top of each component:
const USE_MOCK = !apiBase || true;  // ← change true to false
```

Then reload Caddy's static files (no restart needed — it's a static file).

---

## Port Reference

| Service | Port |
|---|---|
| AgoraIQ main API | 4000 |
| Market Intelligence API | 3001 |
| PostgreSQL | 5432 |
| Redis | 6379 |
