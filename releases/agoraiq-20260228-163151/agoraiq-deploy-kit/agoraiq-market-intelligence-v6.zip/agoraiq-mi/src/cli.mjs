#!/usr/bin/env node
// src/cli.mjs — AgoraIQ Market Intelligence CLI
import { ensureSchema, query, getPool } from './db.mjs';
import { syncAll, syncExchange } from './sync.mjs';
import * as binance  from './exchanges/binance.mjs';
import * as bybit    from './exchanges/bybit.mjs';
import * as kraken   from './exchanges/kraken.mjs';
import * as coinbase from './exchanges/coinbase.mjs';

// Minimal dotenv — load .env file manually
import { readFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const envPath = resolve(__dirname, '..', '.env');

try {
  const envContent = readFileSync(envPath, 'utf8');
  for (const line of envContent.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    const val = trimmed.slice(eqIdx + 1).trim().replace(/^["']|["']$/g, '');
    if (!process.env[key]) process.env[key] = val;
  }
} catch {
  // .env not found — rely on environment variables
}

const ADAPTERS = {
  BINANCE:  binance,
  BYBIT:    bybit,
  KRAKEN:   kraken,
  COINBASE: coinbase,
};

const args    = process.argv.slice(2);
const command = args[0];

// ── Helper ─────────────────────────────────────────────────────────────────────
function printUsage() {
  console.log(`
AgoraIQ Market Intelligence CLI

COMMANDS:
  sync [--exchange BINANCE|BYBIT|KRAKEN|COINBASE] [--force]
    Sync market pairs from exchange APIs into the database.
    Without --exchange, syncs all exchanges sequentially.

  migrate
    Create/update the market_intelligence PostgreSQL schema and tables.
    Safe to run multiple times (idempotent).

  status
    Show current sync health and pair counts.

  help
    Show this help message.

EXAMPLES:
  node src/cli.mjs sync --force
  node src/cli.mjs sync --exchange KRAKEN
  node src/cli.mjs migrate
  node src/cli.mjs status
`);
}

// ── Commands ───────────────────────────────────────────────────────────────────
async function cmdMigrate() {
  console.log('[MI] Running database migration...');
  await ensureSchema();
  console.log('[MI] Migration complete.');
}

async function cmdSync() {
  const exchArg = getFlag(args, '--exchange');
  const force   = args.includes('--force');

  if (exchArg) {
    const key = exchArg.toUpperCase();
    const adapter = ADAPTERS[key];
    if (!adapter) {
      console.error(`[MI] Unknown exchange: ${exchArg}`);
      console.error(`     Valid: ${Object.keys(ADAPTERS).join(', ')}`);
      process.exit(1);
    }
    await cmdMigrate(); // Ensure schema exists
    const result = await syncExchange(adapter, { force });
    printSyncResult([result]);
  } else {
    await cmdMigrate(); // Ensure schema exists
    const results = await syncAll(Object.values(ADAPTERS), { force });
    printSyncResult(results);
  }
}

async function cmdStatus() {
  const pairsRes = await query(
    `SELECT exchange, status, COUNT(*) AS count FROM market_pairs GROUP BY exchange, status ORDER BY exchange, count DESC`
  );
  const syncRes = await query(`
    SELECT DISTINCT ON (exchange) exchange, status, "completedAt", "totalFetched", "durationMs", "errorMessage"
    FROM sync_history
    WHERE status IN ('SUCCESS','PARTIAL','FAILED')
    ORDER BY exchange, "completedAt" DESC
  `);

  console.log('\n══════════════════════════════════════════════');
  console.log(' AgoraIQ Market Intelligence — Status');
  console.log('══════════════════════════════════════════════\n');

  // Group by exchange
  const byExchange = {};
  for (const row of pairsRes.rows) {
    if (!byExchange[row.exchange]) byExchange[row.exchange] = {};
    byExchange[row.exchange][row.status] = parseInt(row.count);
  }

  console.log('MARKET PAIRS:');
  for (const [ex, statuses] of Object.entries(byExchange)) {
    const total = Object.values(statuses).reduce((a, b) => a + b, 0);
    const parts = Object.entries(statuses).map(([s, c]) => `${c} ${s}`).join('  ');
    console.log(`  ${ex.padEnd(10)} ${String(total).padStart(5)} total  [${parts}]`);
  }

  console.log('\nLAST SYNC:');
  for (const row of syncRes.rows) {
    const ts = row.completedAt ? new Date(row.completedAt).toISOString() : 'never';
    const dur = row.durationMs ? `${(row.durationMs / 1000).toFixed(1)}s` : '-';
    const err = row.errorMessage ? `  ⚠ ${row.errorMessage}` : '';
    console.log(`  ${row.exchange.padEnd(10)} ${row.status.padEnd(8)} ${ts}  ${dur.padStart(6)}${err}`);
  }

  console.log('');
}

function printSyncResult(results) {
  console.log('\n══════════════════════════════════════════════');
  console.log(' Sync Complete');
  console.log('══════════════════════════════════════════════');
  for (const r of results) {
    const icon = r.status === 'SUCCESS' ? '✓' : r.status === 'PARTIAL' ? '△' : '✗';
    console.log(`  ${icon} ${r.exchange.padEnd(10)} fetched=${r.fetched} upserted=${r.upserted} skipped=${r.skipped} delisted=${r.delisted} changes=${r.changes}${r.error ? `  ERROR: ${r.error}` : ''}`);
  }
  console.log('');
}

function getFlag(argList, flag) {
  const idx = argList.indexOf(flag);
  return idx !== -1 ? argList[idx + 1] : null;
}

// ── Main ───────────────────────────────────────────────────────────────────────
async function main() {
  switch (command) {
    case 'sync':
      await cmdSync();
      break;
    case 'migrate':
      await cmdMigrate();
      break;
    case 'status':
      await cmdStatus();
      break;
    case 'help':
    case '--help':
    case undefined:
      printUsage();
      process.exit(0);
      break;
    default:
      console.error(`[MI] Unknown command: ${command}`);
      printUsage();
      process.exit(1);
  }
}

main()
  .catch(err => {
    console.error('[MI] Fatal:', err.message);
    process.exit(1);
  })
  .finally(() => {
    // Close DB pool
    getPool().end().catch(() => {});
  });
