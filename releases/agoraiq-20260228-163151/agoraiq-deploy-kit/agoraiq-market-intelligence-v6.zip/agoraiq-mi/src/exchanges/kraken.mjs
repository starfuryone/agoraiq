// src/exchanges/kraken.mjs — Kraken spot market adapter
import fetch from 'node-fetch';
import { SocksProxyAgent } from 'socks-proxy-agent';

const EXCHANGE = 'KRAKEN';
const BASE_URL  = 'https://api.kraken.com';

function getAgent() {
  const host = process.env.SOCKS5_HOST;
  const port = process.env.SOCKS5_PORT || '1080';
  if (!host) return undefined;
  const user = process.env.SOCKS5_USERNAME ? `${process.env.SOCKS5_USERNAME}:${process.env.SOCKS5_PASSWORD}@` : '';
  return new SocksProxyAgent(`socks5://${user}${host}:${port}`);
}

function mapStatus(krakenStatus) {
  // Kraken: "online", "cancel_only", "post_only", "limit_only", "reduce_only"
  switch ((krakenStatus || '').toLowerCase()) {
    case 'online':       return 'ONLINE';
    case 'cancel_only':  return 'CANCEL_ONLY';
    case 'post_only':    return 'POST_ONLY';
    case 'limit_only':   return 'LIMIT_ONLY';
    case 'reduce_only':  return 'REDUCE_ONLY';
    default:             return 'UNKNOWN';
  }
}

/**
 * Normalize Kraken base/quote names to canonical symbols
 * Kraken uses X prefix for crypto (XXBT → BTC) and Z prefix for fiat (ZUSD → USD)
 */
function normalizeAsset(asset) {
  if (!asset) return asset;
  // Known Kraken-specific mappings
  const map = {
    XXBT: 'BTC', XBT: 'BTC',
    XETH: 'ETH', ETH: 'ETH',
    XXRP: 'XRP', XLTC: 'LTC',
    XXLM: 'XLM', XREP: 'REP',
    ZUSD: 'USD', ZEUR: 'EUR',
    ZGBP: 'GBP', ZCAD: 'CAD',
    ZJPY: 'JPY', ZAUD: 'AUD',
  };
  return map[asset] ?? asset;
}

export async function fetchPairs() {
  const agent = getAgent();
  const res = await fetch(`${BASE_URL}/0/public/AssetPairs`, {
    agent,
    timeout: 15000,
    headers: { 'User-Agent': 'AgoraIQ-MarketIntel/6.0' },
  });

  if (!res.ok) throw new Error(`Kraken API error: ${res.status} ${res.statusText}`);

  const data = await res.json();
  if (data.error?.length) throw new Error(`Kraken API: ${data.error.join(', ')}`);

  const pairs = [];

  for (const [pairId, info] of Object.entries(data.result || {})) {
    // Skip dark-pool pairs (have a .d suffix in altname)
    if (pairId.endsWith('.d')) continue;

    const base  = normalizeAsset(info.base);
    const quote = normalizeAsset(info.quote);

    // Build a clean TradingView symbol (use altname which is cleaner)
    const tvName = info.wsname
      ? `KRAKEN:${info.wsname.replace('/', '')}`
      : `KRAKEN:${info.altname}`;

    pairs.push({
      exchange:        EXCHANGE,
      pairId:          pairId,
      symbol:          `${base}/${quote}`,
      baseCanonical:   base,
      quoteCanonical:  quote,
      tvSymbol:        tvName,
      status:          mapStatus(info.status),
      tickSize:        info.tick_size != null ? String(info.tick_size) : null,
      orderMin:        info.ordermin != null ? String(info.ordermin) : null,
      orderMinValue:   info.costmin != null ? String(info.costmin) : null,
      pairDecimals:    info.pair_decimals ?? null,
      lotDecimals:     info.lot_decimals ?? null,
      marginAvailable: Array.isArray(info.leverage_buy) && info.leverage_buy.length > 0,
    });
  }

  return pairs;
}

export { EXCHANGE };
