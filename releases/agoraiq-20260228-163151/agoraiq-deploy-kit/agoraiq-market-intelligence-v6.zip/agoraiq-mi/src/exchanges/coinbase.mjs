// src/exchanges/coinbase.mjs — Coinbase Advanced Trade adapter
import fetch from 'node-fetch';
import { SocksProxyAgent } from 'socks-proxy-agent';

const EXCHANGE = 'COINBASE';
const BASE_URL  = 'https://api.exchange.coinbase.com';

function getAgent() {
  const host = process.env.SOCKS5_HOST;
  const port = process.env.SOCKS5_PORT || '1080';
  if (!host) return undefined;
  const user = process.env.SOCKS5_USERNAME ? `${process.env.SOCKS5_USERNAME}:${process.env.SOCKS5_PASSWORD}@` : '';
  return new SocksProxyAgent(`socks5://${user}${host}:${port}`);
}

function mapStatus(cbStatus) {
  // Coinbase: "online", "offline", "internal", "delisted"
  switch ((cbStatus || '').toLowerCase()) {
    case 'online':   return 'ONLINE';
    case 'offline':  return 'CANCEL_ONLY';
    case 'internal': return 'LIMIT_ONLY';
    case 'delisted': return 'DELISTED';
    default:         return 'UNKNOWN';
  }
}

export async function fetchPairs() {
  const agent = getAgent();
  const res = await fetch(`${BASE_URL}/products`, {
    agent,
    timeout: 15000,
    headers: {
      'User-Agent': 'AgoraIQ-MarketIntel/6.0',
      'Accept': 'application/json',
    },
  });

  if (!res.ok) throw new Error(`Coinbase API error: ${res.status} ${res.statusText}`);

  const products = await res.json();
  const pairs = [];

  for (const prod of products) {
    // Only spot products
    if (prod.trading_disabled) continue;

    const base  = prod.base_currency;
    const quote = prod.quote_currency;

    pairs.push({
      exchange:        EXCHANGE,
      pairId:          prod.id,           // e.g. "BTC-USD"
      symbol:          `${base}/${quote}`,
      baseCanonical:   base,
      quoteCanonical:  quote,
      tvSymbol:        `COINBASE:${base}${quote}`,
      status:          mapStatus(prod.status),
      tickSize:        prod.quote_increment ?? null,
      orderMin:        prod.base_min_size ?? null,
      orderMinValue:   prod.min_market_funds ?? null,
      pairDecimals:    null,
      lotDecimals:     null,
      marginAvailable: false,
    });
  }

  return pairs;
}

export { EXCHANGE };
