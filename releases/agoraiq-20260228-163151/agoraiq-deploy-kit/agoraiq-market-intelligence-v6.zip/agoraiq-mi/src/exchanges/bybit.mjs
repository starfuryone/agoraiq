// src/exchanges/bybit.mjs — Bybit spot market adapter
import fetch from 'node-fetch';
import { SocksProxyAgent } from 'socks-proxy-agent';

const EXCHANGE = 'BYBIT';
const BASE_URL  = 'https://api.bybit.com';

function getAgent() {
  const host = process.env.SOCKS5_HOST;
  const port = process.env.SOCKS5_PORT || '1080';
  if (!host) return undefined;
  const user = process.env.SOCKS5_USERNAME ? `${process.env.SOCKS5_USERNAME}:${process.env.SOCKS5_PASSWORD}@` : '';
  return new SocksProxyAgent(`socks5://${user}${host}:${port}`);
}

function mapStatus(bybitStatus) {
  // Bybit: "Trading", "Settling", "Delivering", "Closed"
  switch ((bybitStatus || '').toLowerCase()) {
    case 'trading':    return 'ONLINE';
    case 'pre-launch': return 'POST_ONLY';
    case 'settling':   return 'REDUCE_ONLY';
    case 'delivering': return 'CANCEL_ONLY';
    case 'closed':     return 'DELISTED';
    default:           return 'UNKNOWN';
  }
}

/**
 * Bybit API supports pagination via cursor, fetch all pages
 */
async function fetchAllSpotInstruments(agent) {
  const results = [];
  let cursor = '';

  do {
    const url = new URL(`${BASE_URL}/v5/market/instruments-info`);
    url.searchParams.set('category', 'spot');
    url.searchParams.set('limit', '1000');
    if (cursor) url.searchParams.set('cursor', cursor);

    const res = await fetch(url.toString(), {
      agent,
      timeout: 15000,
      headers: { 'User-Agent': 'AgoraIQ-MarketIntel/6.0' },
    });

    if (!res.ok) throw new Error(`Bybit API error: ${res.status} ${res.statusText}`);

    const data = await res.json();
    if (data.retCode !== 0) throw new Error(`Bybit API: ${data.retMsg}`);

    const list = data.result?.list || [];
    results.push(...list);
    cursor = data.result?.nextPageCursor || '';
  } while (cursor);

  return results;
}

export async function fetchPairs() {
  const agent = getAgent();
  const instruments = await fetchAllSpotInstruments(agent);
  const pairs = [];

  for (const inst of instruments) {
    const base  = inst.baseCoin;
    const quote = inst.quoteCoin;

    pairs.push({
      exchange:        EXCHANGE,
      pairId:          inst.symbol,
      symbol:          `${base}/${quote}`,
      baseCanonical:   base,
      quoteCanonical:  quote,
      tvSymbol:        `BYBIT:${inst.symbol}`,
      status:          mapStatus(inst.status),
      tickSize:        inst.priceFilter?.tickSize ?? null,
      orderMin:        inst.lotSizeFilter?.minOrderQty ?? null,
      orderMinValue:   inst.lotSizeFilter?.minOrderAmt ?? null,
      pairDecimals:    inst.priceScale != null ? parseInt(inst.priceScale) : null,
      lotDecimals:     inst.basePrecision != null ? parseInt(inst.basePrecision) : null,
      marginAvailable: false, // Bybit spot doesn't expose margin flag directly
    });
  }

  return pairs;
}

export { EXCHANGE };
