// src/exchanges/binance.mjs — Binance spot market adapter
import fetch from 'node-fetch';
import { SocksProxyAgent } from 'socks-proxy-agent';

const EXCHANGE = 'BINANCE';
const BASE_URL  = 'https://api.binance.com';

function getAgent() {
  const host = process.env.SOCKS5_HOST;
  const port = process.env.SOCKS5_PORT || '1080';
  if (!host) return undefined;
  const user = process.env.SOCKS5_USERNAME ? `${process.env.SOCKS5_USERNAME}:${process.env.SOCKS5_PASSWORD}@` : '';
  return new SocksProxyAgent(`socks5://${user}${host}:${port}`);
}

/**
 * Map Binance status string to our normalised status
 */
function mapStatus(binanceStatus) {
  switch (binanceStatus) {
    case 'TRADING':     return 'ONLINE';
    case 'BREAK':       return 'CANCEL_ONLY';
    case 'HALT':        return 'CANCEL_ONLY';
    case 'END_OF_DAY':  return 'CANCEL_ONLY';
    case 'PRE_TRADING': return 'POST_ONLY';
    case 'POST_TRADING':return 'LIMIT_ONLY';
    default:            return 'UNKNOWN';
  }
}

/**
 * Extract tick size from filters array
 */
function getFilter(filters, type) {
  return filters?.find(f => f.filterType === type);
}

export async function fetchPairs() {
  const agent = getAgent();
  const res = await fetch(`${BASE_URL}/api/v3/exchangeInfo`, {
    agent,
    timeout: 15000,
    headers: { 'User-Agent': 'AgoraIQ-MarketIntel/6.0' },
  });

  if (!res.ok) {
    throw new Error(`Binance API error: ${res.status} ${res.statusText}`);
  }

  const data = await res.json();
  const pairs = [];

  for (const sym of data.symbols || []) {
    // Only process spot pairs
    if (sym.isSpot !== true) continue;

    const priceFilter = getFilter(sym.filters, 'PRICE_FILTER');
    const lotFilter   = getFilter(sym.filters, 'LOT_SIZE');
    const minNotional = getFilter(sym.filters, 'MIN_NOTIONAL') || getFilter(sym.filters, 'NOTIONAL');

    const base  = sym.baseAsset;
    const quote = sym.quoteAsset;

    pairs.push({
      exchange:        EXCHANGE,
      pairId:          sym.symbol,
      symbol:          `${base}/${quote}`,
      baseCanonical:   base,
      quoteCanonical:  quote,
      tvSymbol:        `BINANCE:${sym.symbol}`,
      status:          mapStatus(sym.status),
      tickSize:        priceFilter?.tickSize ?? null,
      orderMin:        lotFilter?.minQty ?? null,
      orderMinValue:   minNotional?.minNotional ?? minNotional?.notional ?? null,
      pairDecimals:    sym.quoteAssetPrecision ?? null,
      lotDecimals:     sym.baseAssetPrecision ?? null,
      marginAvailable: sym.isMarginTradingAllowed === true,
    });
  }

  return pairs;
}

export { EXCHANGE };
