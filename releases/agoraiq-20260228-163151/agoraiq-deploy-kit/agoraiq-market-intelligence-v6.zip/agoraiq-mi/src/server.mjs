// src/server.mjs — AgoraIQ Market Intelligence API
import express from 'express';
import cors from 'cors';
import { getPool, healthCheck, query } from './db.mjs';
import { syncExchange, syncAll } from './sync.mjs';

// Exchange adapters (imported lazily so server starts even if adapter fails)
import * as binance  from './exchanges/binance.mjs';
import * as bybit    from './exchanges/bybit.mjs';
import * as kraken   from './exchanges/kraken.mjs';
import * as coinbase from './exchanges/coinbase.mjs';

const ADAPTERS = { BINANCE: binance, BYBIT: bybit, KRAKEN: kraken, COINBASE: coinbase };

const PORT = parseInt(process.env.PORT || '3001', 10);
const app  = express();

// ── Middleware ─────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(cors({
  origin: (process.env.CORS_ORIGIN || 'https://intel.agoraiq.net,https://app.agoraiq.net')
    .split(',').map(s => s.trim()),
  credentials: true,
}));

// Request logger
app.use((req, _res, next) => {
  if (req.path !== '/health') {
    console.log(`[API] ${req.method} ${req.path}`);
  }
  next();
});

// ── Health ─────────────────────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
  const db = await healthCheck();
  res.status(db.ok ? 200 : 503).json({
    status: db.ok ? 'ok' : 'degraded',
    database: db.ok ? 'ok' : db.error,
    service: 'agoraiq-market-intelligence',
    version: '6.0.0',
    timestamp: new Date().toISOString(),
  });
});

// ── GET /api/v1/markets/summary ────────────────────────────────────────────────
app.get('/api/v1/markets/summary', async (_req, res) => {
  try {
    const [totalRes, byExRes, byStRes, topQuoteRes, coverageRes, syncRes] = await Promise.all([
      // Total & tradable counts
      query(`
        SELECT
          COUNT(*) AS "totalMarkets",
          COUNT(*) FILTER (WHERE status IN ('ONLINE','POST_ONLY','LIMIT_ONLY')) AS "tradableMarkets"
        FROM market_pairs
      `),
      // By exchange
      query(`SELECT exchange, COUNT(*) AS count FROM market_pairs GROUP BY exchange ORDER BY count DESC`),
      // By exchange + status
      query(`SELECT exchange, status, COUNT(*) AS count FROM market_pairs GROUP BY exchange, status ORDER BY exchange, count DESC`),
      // Top quote currencies
      query(`SELECT "quoteCanonical" AS quote, COUNT(*) AS count FROM market_pairs GROUP BY "quoteCanonical" ORDER BY count DESC LIMIT 10`),
      // Multi-exchange coverage
      query(`
        SELECT symbol, COUNT(DISTINCT exchange) AS exchanges
        FROM market_pairs WHERE status = 'ONLINE'
        GROUP BY symbol HAVING COUNT(DISTINCT exchange) > 1
        ORDER BY exchanges DESC, symbol LIMIT 20
      `),
      // Last sync per exchange
      query(`
        SELECT DISTINCT ON (exchange)
          exchange, status, "completedAt", "totalFetched", "totalUpserted",
          "totalSkipped", "totalDelisted", "totalChanges", "durationMs"
        FROM sync_history
        WHERE status IN ('SUCCESS','PARTIAL','FAILED')
        ORDER BY exchange, "completedAt" DESC
      `),
    ]);

    const totals = totalRes.rows[0];

    res.json({
      totalMarkets:    parseInt(totals.totalMarkets),
      tradableMarkets: parseInt(totals.tradableMarkets),
      byExchange:      byExRes.rows.map(r => ({ exchange: r.exchange, count: parseInt(r.count) })),
      byStatus:        byStRes.rows.map(r => ({ exchange: r.exchange, status: r.status, count: parseInt(r.count) })),
      topQuoteCurrencies: topQuoteRes.rows.map(r => ({ quote: r.quote, count: parseInt(r.count) })),
      exchangeCoverage:   coverageRes.rows.map(r => ({ symbol: r.symbol, exchanges: parseInt(r.exchanges) })),
      lastSyncHealth:     syncRes.rows.map(r => ({
        exchange:      r.exchange,
        status:        r.status,
        completedAt:   r.completedAt,
        totalFetched:  r.totalFetched,
        totalUpserted: r.totalUpserted,
        totalSkipped:  r.totalSkipped,
        totalDelisted: r.totalDelisted,
        totalChanges:  r.totalChanges,
        durationMs:    r.durationMs,
      })),
    });
  } catch (err) {
    console.error('[API] /summary error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/v1/markets/changelog ─────────────────────────────────────────────
app.get('/api/v1/markets/changelog', async (req, res) => {
  try {
    const limit    = Math.min(parseInt(req.query.limit || '50'), 500);
    const exchange = req.query.exchange;
    const type     = req.query.changeType;

    const conditions = [];
    const params     = [];

    if (exchange) { params.push(exchange); conditions.push(`exchange = $${params.length}`); }
    if (type)     { params.push(type);     conditions.push(`"changeType" = $${params.length}`); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    params.push(limit);

    const result = await query(
      `SELECT id, exchange, "pairId", "changeType", "fieldName", "oldValue", "newValue", "detectedAt"
       FROM market_changelog ${where}
       ORDER BY "detectedAt" DESC
       LIMIT $${params.length}`,
      params
    );

    res.json({ data: result.rows, total: result.rowCount });
  } catch (err) {
    console.error('[API] /changelog error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/v1/markets/sync/history ──────────────────────────────────────────
app.get('/api/v1/markets/sync/history', async (req, res) => {
  try {
    const limit    = Math.min(parseInt(req.query.limit || '20'), 100);
    const exchange = req.query.exchange;

    const params = [];
    const where  = exchange ? (params.push(exchange), `WHERE exchange = $1`) : '';
    params.push(limit);

    const result = await query(
      `SELECT id, exchange, status, "totalFetched", "totalUpserted", "totalSkipped",
              "totalDelisted", "totalChanges", "durationMs", "errorMessage", "startedAt", "completedAt"
       FROM sync_history ${where}
       ORDER BY "startedAt" DESC
       LIMIT $${params.length}`,
      params
    );

    res.json({ data: result.rows, total: result.rowCount });
  } catch (err) {
    console.error('[API] /sync/history error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/v1/markets/pairs ─────────────────────────────────────────────────
app.get('/api/v1/markets/pairs', async (req, res) => {
  try {
    const limit    = Math.min(parseInt(req.query.limit || '500'), 5000);
    const offset   = parseInt(req.query.offset || '0');
    const exchange = req.query.exchange;
    const status   = req.query.status;
    const search   = req.query.q;
    const margin   = req.query.marginOnly === 'true';

    const conditions = [];
    const params     = [];

    if (exchange) { params.push(exchange); conditions.push(`exchange = $${params.length}`); }
    if (status)   { params.push(status);   conditions.push(`status = $${params.length}`); }
    if (margin)   { conditions.push(`"marginAvailable" = TRUE`); }
    if (search) {
      params.push(`%${search.toUpperCase()}%`);
      conditions.push(`(UPPER(symbol) LIKE $${params.length} OR UPPER("pairId") LIKE $${params.length} OR UPPER("baseCanonical") LIKE $${params.length})`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    // Count query
    const countRes = await query(
      `SELECT COUNT(*) AS total FROM market_pairs ${where}`,
      params
    );

    // Data query
    params.push(limit, offset);
    const dataRes = await query(
      `SELECT id, exchange, "pairId", symbol, "baseCanonical", "quoteCanonical", "tvSymbol",
              status, "tickSize", "orderMin", "orderMinValue", "pairDecimals", "lotDecimals",
              "marginAvailable", "lastSyncedAt"
       FROM market_pairs ${where}
       ORDER BY exchange, symbol
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );

    res.json({
      data:   dataRes.rows,
      total:  parseInt(countRes.rows[0].total),
      limit,
      offset,
    });
  } catch (err) {
    console.error('[API] /pairs error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/v1/markets/pairs/:exchange/:pairId ────────────────────────────────
app.get('/api/v1/markets/pairs/:exchange/:pairId', async (req, res) => {
  try {
    const { exchange, pairId } = req.params;
    const result = await query(
      `SELECT * FROM market_pairs WHERE exchange = $1 AND "pairId" = $2`,
      [exchange.toUpperCase(), pairId]
    );
    if (!result.rows.length) return res.status(404).json({ error: 'Pair not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/v1/markets/sync ─────────────────────────────────────────────────
// Trigger manual sync (runs in background, returns immediately)
app.post('/api/v1/markets/sync', async (req, res) => {
  try {
    const { exchange, force = false } = req.body || {};
    const adapters = exchange
      ? [ADAPTERS[exchange.toUpperCase()]].filter(Boolean)
      : Object.values(ADAPTERS);

    if (exchange && !ADAPTERS[exchange.toUpperCase()]) {
      return res.status(400).json({ error: `Unknown exchange: ${exchange}` });
    }

    res.json({ message: 'Sync started', exchange: exchange || 'ALL', force });

    // Run async after response
    setImmediate(async () => {
      try {
        await syncAll(adapters, { force });
      } catch (err) {
        console.error('[API] Background sync error:', err);
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/v1/markets/validate ──────────────────────────────────────────────
// Check if a symbol/exchange combination exists and is tradable
app.get('/api/v1/markets/validate', async (req, res) => {
  try {
    const { symbol, exchange } = req.query;
    if (!symbol) return res.status(400).json({ error: 'symbol required' });

    const conditions = [`(UPPER(symbol) = $1 OR UPPER("pairId") = $1 OR UPPER("baseCanonical") = $1)`];
    const params = [symbol.toUpperCase()];

    if (exchange) {
      params.push(exchange.toUpperCase());
      conditions.push(`exchange = $2`);
    }

    const result = await query(
      `SELECT exchange, "pairId", symbol, "tvSymbol", status, "marginAvailable"
       FROM market_pairs WHERE ${conditions.join(' AND ')}
       ORDER BY exchange`,
      params
    );

    const tradable = result.rows.filter(r => ['ONLINE', 'POST_ONLY', 'LIMIT_ONLY'].includes(r.status));
    res.json({
      symbol,
      found: result.rows.length > 0,
      tradable: tradable.length > 0,
      pairs: result.rows,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Error handler ──────────────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('[API] Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// ── Start ──────────────────────────────────────────────────────────────────────
app.listen(PORT, '127.0.0.1', () => {
  console.log(`[AgoraIQ-MI] Market Intelligence API running on port ${PORT}`);
  console.log(`[AgoraIQ-MI] Exchanges: ${Object.keys(ADAPTERS).join(', ')}`);
  // Warm up DB connection
  getPool();
});
