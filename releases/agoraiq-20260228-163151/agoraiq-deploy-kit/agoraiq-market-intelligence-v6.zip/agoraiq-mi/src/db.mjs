// src/db.mjs — PostgreSQL client for market_intelligence schema
import pg from 'pg';

const { Pool } = pg;

let _pool = null;

export function getPool() {
  if (!_pool) {
    const dbUrl = process.env.DATABASE_URL;
    if (!dbUrl) throw new Error('DATABASE_URL not set');

    // Parse schema from ?schema=X query param and set search_path
    const url = new URL(dbUrl);
    const schema = url.searchParams.get('schema') || 'market_intelligence';

    _pool = new Pool({
      connectionString: dbUrl,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    });

    // Set search_path on every new connection
    _pool.on('connect', async (client) => {
      await client.query(`SET search_path TO ${schema}, public`);
    });

    _pool.on('error', (err) => {
      console.error('[DB] Pool error:', err.message);
    });
  }
  return _pool;
}

export async function query(sql, params = []) {
  const pool = getPool();
  const client = await pool.connect();
  try {
    const result = await client.query(sql, params);
    return result;
  } finally {
    client.release();
  }
}

export async function healthCheck() {
  try {
    const result = await query('SELECT 1 AS ok');
    // Also verify the market_intelligence schema tables exist
    const tables = await query(`
      SELECT table_name FROM information_schema.tables
      WHERE table_schema = 'market_intelligence'
        AND table_name IN ('market_pairs', 'market_changelog', 'sync_history')
    `);
    return {
      ok: true,
      tablesFound: tables.rows.map(r => r.table_name),
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

export async function ensureSchema() {
  await query('CREATE SCHEMA IF NOT EXISTS market_intelligence');

  await query(`SET search_path TO market_intelligence, public`);

  await query(`
    CREATE TABLE IF NOT EXISTS market_pairs (
      id              TEXT         NOT NULL,
      exchange        TEXT         NOT NULL,
      "pairId"        TEXT         NOT NULL,
      symbol          TEXT         NOT NULL,
      "baseCanonical" TEXT         NOT NULL,
      "quoteCanonical" TEXT        NOT NULL,
      "tvSymbol"      TEXT,
      status          TEXT         NOT NULL DEFAULT 'ONLINE',
      "tickSize"      TEXT,
      "orderMin"      TEXT,
      "orderMinValue" TEXT,
      "pairDecimals"  INTEGER,
      "lotDecimals"   INTEGER,
      "marginAvailable" BOOLEAN    NOT NULL DEFAULT FALSE,
      "rawData"       JSONB,
      "lastSyncedAt"  TIMESTAMP(3) NOT NULL DEFAULT NOW(),
      "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT NOW(),
      "updatedAt"     TIMESTAMP(3) NOT NULL DEFAULT NOW(),
      CONSTRAINT market_pairs_pkey PRIMARY KEY (id),
      CONSTRAINT market_pairs_exchange_pair_key UNIQUE (exchange, "pairId")
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS market_changelog (
      id          TEXT         NOT NULL,
      exchange    TEXT         NOT NULL,
      "pairId"    TEXT         NOT NULL,
      "changeType" TEXT        NOT NULL,
      "fieldName" TEXT         NOT NULL,
      "oldValue"  TEXT,
      "newValue"  TEXT,
      "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT NOW(),
      CONSTRAINT market_changelog_pkey PRIMARY KEY (id)
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS sync_history (
      id              TEXT         NOT NULL,
      exchange        TEXT         NOT NULL,
      status          TEXT         NOT NULL DEFAULT 'RUNNING',
      "totalFetched"  INTEGER      NOT NULL DEFAULT 0,
      "totalUpserted" INTEGER      NOT NULL DEFAULT 0,
      "totalSkipped"  INTEGER      NOT NULL DEFAULT 0,
      "totalDelisted" INTEGER      NOT NULL DEFAULT 0,
      "totalChanges"  INTEGER      NOT NULL DEFAULT 0,
      "durationMs"    INTEGER,
      "errorMessage"  TEXT,
      "startedAt"     TIMESTAMP(3) NOT NULL DEFAULT NOW(),
      "completedAt"   TIMESTAMP(3),
      CONSTRAINT sync_history_pkey PRIMARY KEY (id)
    )
  `);

  // Indexes
  const idxQueries = [
    `CREATE INDEX IF NOT EXISTS mi_pairs_exchange_idx ON market_intelligence.market_pairs(exchange)`,
    `CREATE INDEX IF NOT EXISTS mi_pairs_base_idx ON market_intelligence.market_pairs("baseCanonical")`,
    `CREATE INDEX IF NOT EXISTS mi_pairs_quote_idx ON market_intelligence.market_pairs("quoteCanonical")`,
    `CREATE INDEX IF NOT EXISTS mi_pairs_status_idx ON market_intelligence.market_pairs(status)`,
    `CREATE INDEX IF NOT EXISTS mi_changelog_exchange_idx ON market_intelligence.market_changelog(exchange)`,
    `CREATE INDEX IF NOT EXISTS mi_changelog_detected_idx ON market_intelligence.market_changelog("detectedAt")`,
    `CREATE INDEX IF NOT EXISTS mi_sync_exchange_idx ON market_intelligence.sync_history(exchange)`,
    `CREATE INDEX IF NOT EXISTS mi_sync_completed_idx ON market_intelligence.sync_history("completedAt")`,
  ];
  for (const idxQ of idxQueries) {
    await query(idxQ).catch(() => {}); // ignore if already exists
  }

  console.log('[DB] Schema market_intelligence ensured ✓');
}

// Generate a cuid-like unique id
export function genId() {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 10);
  return `c${ts}${rand}`;
}
