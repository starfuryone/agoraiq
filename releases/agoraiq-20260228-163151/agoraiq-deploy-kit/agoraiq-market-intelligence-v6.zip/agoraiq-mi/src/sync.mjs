// src/sync.mjs — Market data sync engine
import { query, genId } from './db.mjs';

const TRACKED_FIELDS = [
  'status', 'tickSize', 'orderMin', 'orderMinValue',
  'pairDecimals', 'lotDecimals', 'marginAvailable',
];

function detectChanges(existing, incoming, exchange, pairId) {
  const changes = [];
  for (const field of TRACKED_FIELDS) {
    const oldVal = existing[field] != null ? String(existing[field]) : null;
    const newVal = incoming[field] != null ? String(incoming[field]) : null;
    if (oldVal === newVal) continue;

    // Determine a meaningful changeType
    let changeType = 'STATUS_CHANGE';
    if (field === 'status') {
      if (newVal === 'DELISTED') changeType = 'DELIST';
      else if (oldVal === 'DELISTED') changeType = 'RELIST';
      else changeType = 'STATUS_CHANGE';
    } else if (field === 'tickSize') {
      changeType = 'TICK_CHANGE';
    } else if (field === 'marginAvailable') {
      changeType = 'MARGIN_CHANGE';
    } else if (field === 'pairDecimals' || field === 'lotDecimals') {
      changeType = 'DECIMAL_CHANGE';
    } else if (field === 'orderMin' || field === 'orderMinValue') {
      changeType = 'MIN_ORDER_CHANGE';
    } else {
      changeType = 'TRADABLE_CHANGE';
    }

    changes.push({ exchange, pairId, changeType, fieldName: field, oldValue: oldVal, newValue: newVal });
  }
  return changes;
}

/**
 * Run a sync for one exchange adapter
 * Returns sync stats
 */
export async function syncExchange(adapter, opts = {}) {
  const { force = false } = opts;
  const exchange = adapter.EXCHANGE;
  const startedAt = new Date();
  const syncId = genId();

  console.log(`[SYNC] ${exchange}: starting`);

  // Insert RUNNING record
  await query(
    `INSERT INTO sync_history (id, exchange, status, "startedAt") VALUES ($1, $2, 'RUNNING', $3)`,
    [syncId, exchange, startedAt]
  );

  const stats = { fetched: 0, upserted: 0, skipped: 0, delisted: 0, changes: 0 };
  let errorMessage = null;

  try {
    // 1. Fetch from exchange
    const pairs = await adapter.fetchPairs();
    stats.fetched = pairs.length;
    console.log(`[SYNC] ${exchange}: fetched ${pairs.length} pairs`);

    // 2. Load existing pairs for this exchange
    const existingRes = await query(
      `SELECT * FROM market_pairs WHERE exchange = $1`,
      [exchange]
    );
    const existingMap = new Map(existingRes.rows.map(r => [r.pairId, r]));
    const incomingSet = new Set(pairs.map(p => p.pairId));

    // 3. Detect delisted pairs (in DB but not in incoming)
    for (const [pairId, existing] of existingMap.entries()) {
      if (!incomingSet.has(pairId) && existing.status !== 'DELISTED') {
        // Mark as DELISTED
        await query(
          `UPDATE market_pairs SET status = 'DELISTED', "lastSyncedAt" = NOW(), "updatedAt" = NOW()
           WHERE exchange = $1 AND "pairId" = $2`,
          [exchange, pairId]
        );

        // Log the change
        await query(
          `INSERT INTO market_changelog (id, exchange, "pairId", "changeType", "fieldName", "oldValue", "newValue", "detectedAt")
           VALUES ($1, $2, $3, 'DELIST', 'status', $4, 'DELISTED', NOW())`,
          [genId(), exchange, pairId, existing.status]
        );
        stats.delisted++;
        stats.changes++;
      }
    }

    // 4. Upsert incoming pairs
    for (const pair of pairs) {
      const existing = existingMap.get(pair.pairId);

      if (existing) {
        // Diff and log changes
        const pairChanges = detectChanges(existing, pair, exchange, pair.pairId);
        if (pairChanges.length > 0 || force) {
          // Update the row
          await query(
            `UPDATE market_pairs SET
               symbol = $3, "baseCanonical" = $4, "quoteCanonical" = $5, "tvSymbol" = $6,
               status = $7, "tickSize" = $8, "orderMin" = $9, "orderMinValue" = $10,
               "pairDecimals" = $11, "lotDecimals" = $12, "marginAvailable" = $13,
               "lastSyncedAt" = NOW(), "updatedAt" = NOW()
             WHERE exchange = $1 AND "pairId" = $2`,
            [
              exchange, pair.pairId, pair.symbol,
              pair.baseCanonical, pair.quoteCanonical, pair.tvSymbol,
              pair.status, pair.tickSize, pair.orderMin, pair.orderMinValue,
              pair.pairDecimals, pair.lotDecimals, pair.marginAvailable,
            ]
          );

          // Insert changelog entries
          for (const change of pairChanges) {
            await query(
              `INSERT INTO market_changelog (id, exchange, "pairId", "changeType", "fieldName", "oldValue", "newValue", "detectedAt")
               VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
              [genId(), change.exchange, change.pairId, change.changeType, change.fieldName, change.oldValue, change.newValue]
            );
          }
          stats.changes += pairChanges.length;
          stats.upserted++;
        } else {
          // Only update lastSyncedAt
          await query(
            `UPDATE market_pairs SET "lastSyncedAt" = NOW() WHERE exchange = $1 AND "pairId" = $2`,
            [exchange, pair.pairId]
          );
          stats.skipped++;
        }
      } else {
        // New listing — insert
        await query(
          `INSERT INTO market_pairs
             (id, exchange, "pairId", symbol, "baseCanonical", "quoteCanonical", "tvSymbol",
              status, "tickSize", "orderMin", "orderMinValue", "pairDecimals", "lotDecimals",
              "marginAvailable", "lastSyncedAt", "createdAt", "updatedAt")
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,NOW(),NOW(),NOW())
           ON CONFLICT (exchange,"pairId") DO NOTHING`,
          [
            genId(), exchange, pair.pairId, pair.symbol,
            pair.baseCanonical, pair.quoteCanonical, pair.tvSymbol,
            pair.status, pair.tickSize, pair.orderMin, pair.orderMinValue,
            pair.pairDecimals, pair.lotDecimals, pair.marginAvailable,
          ]
        );

        // Log new listing in changelog
        await query(
          `INSERT INTO market_changelog (id, exchange, "pairId", "changeType", "fieldName", "oldValue", "newValue", "detectedAt")
           VALUES ($1, $2, $3, 'NEW_LISTING', 'pairId', NULL, $4, NOW())`,
          [genId(), exchange, pair.pairId, pair.pairId]
        );
        stats.upserted++;
        stats.changes++;
      }
    }

    console.log(`[SYNC] ${exchange}: done — fetched=${stats.fetched} upserted=${stats.upserted} skipped=${stats.skipped} delisted=${stats.delisted} changes=${stats.changes}`);

    // 5. Update sync history as SUCCESS
    const durationMs = Date.now() - startedAt.getTime();
    await query(
      `UPDATE sync_history SET
         status = 'SUCCESS', "totalFetched" = $2, "totalUpserted" = $3, "totalSkipped" = $4,
         "totalDelisted" = $5, "totalChanges" = $6, "durationMs" = $7, "completedAt" = NOW()
       WHERE id = $1`,
      [syncId, stats.fetched, stats.upserted, stats.skipped, stats.delisted, stats.changes, durationMs]
    );

    return { exchange, status: 'SUCCESS', ...stats };

  } catch (err) {
    errorMessage = err.message;
    console.error(`[SYNC] ${exchange}: FAILED — ${err.message}`);

    const durationMs = Date.now() - startedAt.getTime();
    const status = stats.fetched > 0 ? 'PARTIAL' : 'FAILED';
    await query(
      `UPDATE sync_history SET
         status = $2, "totalFetched" = $3, "totalUpserted" = $4, "totalSkipped" = $5,
         "totalDelisted" = $6, "totalChanges" = $7, "durationMs" = $8,
         "errorMessage" = $9, "completedAt" = NOW()
       WHERE id = $1`,
      [syncId, status, stats.fetched, stats.upserted, stats.skipped, stats.delisted, stats.changes, durationMs, errorMessage]
    );

    return { exchange, status, error: errorMessage, ...stats };
  }
}

/**
 * Run all adapters concurrently (or sequentially for a specific exchange)
 */
export async function syncAll(adapters, opts = {}) {
  const results = [];
  // Run sequentially to avoid hammering the DB with concurrent writes
  for (const adapter of adapters) {
    const result = await syncExchange(adapter, opts);
    results.push(result);
  }
  return results;
}
