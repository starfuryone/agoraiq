-- AgoraIQ Market Intelligence — Initial Migration
-- Creates the market_intelligence schema and all tables

-- Create schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS market_intelligence;

-- Set search path for this migration
SET search_path TO market_intelligence;

-- Market Pairs
CREATE TABLE IF NOT EXISTS "market_pairs" (
    "id"              TEXT        NOT NULL,
    "exchange"        TEXT        NOT NULL,
    "pairId"          TEXT        NOT NULL,
    "symbol"          TEXT        NOT NULL,
    "baseCanonical"   TEXT        NOT NULL,
    "quoteCanonical"  TEXT        NOT NULL,
    "tvSymbol"        TEXT,
    "status"          TEXT        NOT NULL DEFAULT 'ONLINE',
    "tickSize"        TEXT,
    "orderMin"        TEXT,
    "orderMinValue"   TEXT,
    "pairDecimals"    INTEGER,
    "lotDecimals"     INTEGER,
    "marginAvailable" BOOLEAN     NOT NULL DEFAULT FALSE,
    "rawData"         JSONB,
    "lastSyncedAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "market_pairs_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "market_pairs_exchange_pairId_key" UNIQUE ("exchange", "pairId")
);

CREATE INDEX IF NOT EXISTS "market_pairs_exchange_idx"       ON "market_pairs"("exchange");
CREATE INDEX IF NOT EXISTS "market_pairs_baseCanonical_idx"  ON "market_pairs"("baseCanonical");
CREATE INDEX IF NOT EXISTS "market_pairs_quoteCanonical_idx" ON "market_pairs"("quoteCanonical");
CREATE INDEX IF NOT EXISTS "market_pairs_status_idx"         ON "market_pairs"("status");

-- Market Changelog
CREATE TABLE IF NOT EXISTS "market_changelog" (
    "id"         TEXT         NOT NULL,
    "exchange"   TEXT         NOT NULL,
    "pairId"     TEXT         NOT NULL,
    "changeType" TEXT         NOT NULL,
    "fieldName"  TEXT         NOT NULL,
    "oldValue"   TEXT,
    "newValue"   TEXT,
    "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "market_changelog_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "market_changelog_exchange_idx"   ON "market_changelog"("exchange");
CREATE INDEX IF NOT EXISTS "market_changelog_detectedAt_idx" ON "market_changelog"("detectedAt");

-- Sync History
CREATE TABLE IF NOT EXISTS "sync_history" (
    "id"            TEXT         NOT NULL,
    "exchange"      TEXT         NOT NULL,
    "status"        TEXT         NOT NULL DEFAULT 'RUNNING',
    "totalFetched"  INTEGER      NOT NULL DEFAULT 0,
    "totalUpserted" INTEGER      NOT NULL DEFAULT 0,
    "totalSkipped"  INTEGER      NOT NULL DEFAULT 0,
    "totalDelisted" INTEGER      NOT NULL DEFAULT 0,
    "totalChanges"  INTEGER      NOT NULL DEFAULT 0,
    "durationMs"    INTEGER,
    "errorMessage"  TEXT,
    "startedAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt"   TIMESTAMP(3),

    CONSTRAINT "sync_history_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "sync_history_exchange_idx"    ON "sync_history"("exchange");
CREATE INDEX IF NOT EXISTS "sync_history_completedAt_idx" ON "sync_history"("completedAt");

-- Prisma migrations table (required by prisma migrate)
SET search_path TO public;
